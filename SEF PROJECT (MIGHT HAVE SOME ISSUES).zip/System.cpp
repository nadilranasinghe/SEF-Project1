#include "System.h"
#include <string.h> 
#include <stdio.h>
#include <time.h>

//Nadil

void mainMenu() {
    printf("\n===== PWH Warehouse System =====\n");
    printf("1. Parts Management\n");
    printf("2. Customer Management\n");
    printf("3. Order Management\n");
    printf("4. Exit System\n");
    printf("===============================\n");
    printf("Select option: ");
}

void partsSubMenu() {
    printf("\n----- Parts Management -----\n");
    printf("1. List All Parts\n");
    printf("2. Search for Part\n");
    printf("3. Add New Part\n");
    printf("4. Update Part Inventory\n");
    printf("5. Load Parts Database\n");
    printf("6. Save Parts Database\n");
    printf("7. Return to Main Menu\n");
    printf("----------------------------\n");
    printf("Select option: ");
}

void customerSubMenu() {
    printf("\n----- Customer Management -----\n");
    printf("1. List All Customers\n");
    printf("2. Search for Customer\n");
    printf("3. Add New Customer\n");
    printf("4. Update Customer Information\n");
    printf("5. List Bad Credit Customers\n");
    printf("6. Load Customer Database\n");
    printf("7. Save Customer Database\n");
    printf("8. Return to Main Menu\n");
    printf("-------------------------------\n");
    printf("Select option: ");
}

void orderSubMenu() {
    printf("\n----- Order Management -----\n");
    printf("1. List All Orders\n");
    printf("2. Search for Order\n");
    printf("3. Create New Order\n");
    printf("4. Process End-of-Day Orders\n");
    printf("5. Load Order Database\n");
    printf("6. Save Order Database\n");
    printf("7. Return to Main Menu\n");
    printf("---------------------------\n");
    printf("Select option: ");
}

void logMessage(const char* message) {
    FILE* logFile;
    errno_t err = fopen_s(&logFile, "system.log", "a");
    if (err == 0 && logFile != NULL) {
        time_t now;
        time(&now);
        char timestamp[26];
        ctime_s(timestamp, sizeof(timestamp), &now);
        timestamp[strlen(timestamp) - 1] = '\0';

        fprintf(logFile, "[%s] %s\n", timestamp, message);
        fclose(logFile);
    }
}