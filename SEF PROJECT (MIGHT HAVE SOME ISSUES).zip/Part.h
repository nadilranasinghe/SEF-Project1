#ifndef PART_H
#define PART_H

#define MAXIMUMLENGTH 51
#define MAXPARTSIZE 100
#define MAXLINE 100
#define LOCATELINE 10

//Che Ping

typedef struct {
    char PartName[MAXIMUMLENGTH];
    char PartNumber[MAXIMUMLENGTH];
    char PartLocate[MAXIMUMLENGTH];
    float PartCost;
    int QuantityOnHand;
    int PartStatus;
    int PartID;
} Parts;

void ListallParts(Parts* part, int* size);
void SearchforPart(Parts* part, int* size);
int AddPart(Parts* part, int* size);
void UpdateInventoryforPart(Parts part[], int* size);
void SaveToFile(const char* filename, Parts part[], int* size);
void loadfromfile(const char* filename, Parts part[], int* size);
void handlePartsMenu(Parts parts[], int* partsCount);

#endif