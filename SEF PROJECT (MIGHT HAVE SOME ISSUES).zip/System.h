#ifndef SYSTEM_H
#define SYSTEM_H

//Nadil

void mainMenu();
void partsSubMenu();
void customerSubMenu();
void orderSubMenu();
void logMessage(const char* message);

#endif