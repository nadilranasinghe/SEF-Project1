#ifndef ORDER_H
#define ORDER_H

#include "Customer.h"
#include "Part.h"

//Nadil

#define MAX_PARTS_PER_ORDER 50
#define MAX_ORDERS 100
#define LENGTH_OF_DATE 11

#define STATUS_PLACED 0
#define STATUS_FULFILLED 1
#define STATUS_INSUFFICIENT_PARTS 99
#define STATUS_CREDIT_LIMIT_EXCEEDED 500

typedef struct {
    int PartID;
    int NumberOfParts;
} OrderItem;

typedef struct {
    long OrderID;
    char OrderDate[LENGTH_OF_DATE];
    int OrderStatus;
    int CustomerID;
    float OrderTotal;
    int DistinctParts;
    int TotalParts;
    OrderItem Items[MAX_PARTS_PER_ORDER];
} Order;

long generateOrderID();
bool validateDate(const char* date);
void createNewOrder(Order orders[], int* orderCount, Customer customers[], int customerCount, Parts parts[], int partsCount);
void displayOrderDetails(long orderID, Order orders[], int orderCount);
void updateOrderStatus(long orderID, int newStatus, Order orders[], int orderCount);
void listAllOrders(Order orders[], int orderCount);
void processEndOfDayOrders(Order orders[], int* orderCount, Customer customers[], int customerCount, Parts parts[], int partsCount);
void loadOrderFromFile(Order orders[], int* orderCount);
void saveOrderToFile(Order orders[], int orderCount);
void handleOrdersMenu(Order orders[], int* orderCount, Customer customers[], int customerCount, Parts parts[], int partsCount);

#endif