#ifndef CUSTOMER_H
#define CUSTOMER_H

#define MAX_CUSTOMERS 50
#define MAX_LINE_LENGTH 512
#define MAX_INPUT_LENGTH 100

// Simmy

typedef struct {
    int customerID;
    char name[51];
    char address[101];
    char city[101];
    char province[3];
    char postalCode[7];
    char phone[13];
    char email[51];
    float creditLimit;
    float accountBalance;
    char joinDate[11];
    char lastPayment[11];
} Customer;

void customersMenu(Customer customers[], int* count);
void listAllCustomers(Customer customers[], int count);
void searchCustomer(Customer customers[], int count);
void addCustomer(Customer customers[], int* count);
void updateCustomerInfo(Customer customers[], int count);
void listBadCreditCustomers(Customer customers[], int count);
int loadCustomers(Customer customers[], int max);
void saveCustomers(Customer customers[], int count);
int isValidProvince(const char* code);
int isValidPostalCode(const char* code);
int isValidPhone(const char* phone);
int isValidDateFormat(const char* date);

#endif