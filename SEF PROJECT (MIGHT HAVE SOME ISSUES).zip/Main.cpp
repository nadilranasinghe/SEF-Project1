#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Customer.h"
#include "Part.h"
#include "Order.h"
#include "System.h"

//Najaf

int main(void) {
    Customer customers[MAX_CUSTOMERS];
    Parts parts[MAXPARTSIZE];
    Order orders[MAX_ORDERS];

    int customerCount = loadCustomers(customers, MAX_CUSTOMERS);
    int partsCount = 0;
    loadfromfile("parts.db", parts, &partsCount);
    int orderCount = 0;
    loadOrderFromFile(orders, &orderCount);

    printf("\n=== PWH Warehouse System Initialized ===\n");
    printf("Customers loaded: %d\n", customerCount);
    printf("Parts loaded: %d\n", partsCount);
    printf("Orders loaded: %d\n", orderCount);
    printf("=======================================\n");

    int choice;
    char buffer[100];

    do {
        mainMenu();

        if (!fgets(buffer, sizeof(buffer), stdin)) continue;
        if (sscanf_s(buffer, "%d", &choice) != 1) {
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
        case 1: handlePartsMenu(parts, &partsCount); break;
        case 2: customersMenu(customers, &customerCount); break;
        case 3: handleOrdersMenu(orders, &orderCount, customers, customerCount, parts, partsCount); break;
        case 4:
            printf("\nSaving data...\n");
            saveCustomers(customers, customerCount);
            SaveToFile("parts.db", parts, &partsCount);
            saveOrderToFile(orders, orderCount);
            printf("Data saved. Goodbye!\n");
            break;
        default:
            printf("Invalid option.\n");
        }
    } while (choice != 4);

    return 0;
}